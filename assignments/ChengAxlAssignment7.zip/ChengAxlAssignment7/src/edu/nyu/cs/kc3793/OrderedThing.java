package edu.nyu.cs.kc3793;


public class OrderedThing {

}
