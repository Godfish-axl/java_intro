/**
 * @date 20190909;
 * @author Axl Cheng;
 * @file ChengAxlAssignment1Part1.java*/

package edu.nyu.cs.kc3793;

public class ChengAxlAssignment1Part1 {
/*1.10*/
	public static void main(String[] args) {
		double averagespeed;
		averagespeed = (14 / 1.6) / (45.5 / 60);
		System.out.println("Assume a runner runs 14 kilometers in 45 minutes and 30 seconds, the average speed is " + averagespeed + " miles per hour.");
	}
}